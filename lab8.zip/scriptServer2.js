// Crea una pequeña aplicación web que al enviar una petición al servidor, devuelva una de las 
// páginas que creaste anteriormente en tus laboratorios.

// para iniciar el servidor en terminal: node scriptServer2.js
// para cerrar el servidor en terminal: ctrl+c
// para probar el server escribir la ruta http://localhost:8080/ en navegador

const http = require('http');
const fs = require('fs');

const servidor = http.createServer((req, res) => {
    // Manejo de errores
    req.on('error', err => {
        console.error(err);
        res.statusCode = 400;
        res.end();
    });
    res.on('error', err => {
        console.error(err);
    });

    // Si la solicitud es un POST a la ruta "/echo", devolver el cuerpo de la solicitud
    if (req.method === 'POST' && req.url === '/echo') {
        req.pipe(res);
    } else {
        // Si la solicitud es GET a la ruta "/", devolver la página HTML
        if (req.method === 'GET' && req.url === '/') {
            fs.readFile('lab5.html', (err, data) => {
                if (err) {
                    res.writeHead(500);
                    return res.end('Error interno del servidor');
                }
        
                res.writeHead(200, {'Content-Type': 'text/html'});
                res.write(data);
                res.end();
            });
        } else {
            // Si la solicitud no coincide con ninguna ruta conocida, devolver un error 404
            res.statusCode = 404;
            res.end();
        }
    }
});

const puerto = 8080;
servidor.listen(puerto, () => {
    console.log(`Servidor en funcionamiento en http://localhost:${puerto}`);
});

