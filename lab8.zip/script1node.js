// Una función que reciba un arreglo de números y devuelva su promedio.

// Para correr en terminal: node script1node.js

"use strict";

function calcularPromedio(arreglo) {
    if (arreglo.length === 0) {
        return 0; 
    }
    const suma = arreglo.reduce((total, num) => total + num, 0);
    return suma / arreglo.length;
}


const numeros = [10, 20, 30, 40, 50];
const promedio = calcularPromedio(numeros);
console.log("El promedio es:", promedio);