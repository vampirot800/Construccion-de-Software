// Escoge algún problema que hayas implementado en otro lenguaje de programación, 
// y dale una solución en js que se ejecute sobre node.

// Para correr en terminal: node script3node.js

"use strict";

"use strict";

const readline = require('readline');

class CuentaBancaria {
    constructor(titular, RFC, saldo = 0) {
        this.titular = titular;
        this.RFC = RFC;
        this.saldo = saldo;
    }

    depositar(cantidad) {
        if (cantidad > 0) {
            this.saldo += cantidad;
            console.log(`Se han depositado: $${cantidad} pesos en la cuenta.`);
        } else {
            console.log("La cantidad a depositar debe ser mayor que cero.");
        }
    }

    retirar(cantidad) {
        if (cantidad > 0 && cantidad <= this.saldo) {
            this.saldo -= cantidad;
            console.log(`Se han retirado: $${cantidad} pesos de la cuenta.`);
        } else {
            console.log("No se puede retirar la cantidad especificada. Fondos insuficientes o cantidad inválida.");
        }
    }

    imprimirInfo() {
        console.log(`Información de la cuenta:\nTitular: ${this.titular}\nRFC: ${this.RFC}\nSaldo actual: $${this.saldo}`);
    }
}

const cuenta = new CuentaBancaria("Ramiro Flores Villarreal", "FOVR021020P94", 5000);
cuenta.imprimirInfo();

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("¿Qué desea hacer? (depositar/retirar) ", (opcion) => {
    if (opcion === "depositar") {
        rl.question("Ingrese la cantidad a depositar: ", (cantidad) => {
            cuenta.depositar(parseFloat(cantidad));
            cuenta.imprimirInfo();
            rl.close();
        });
    } else if (opcion === "retirar") {
        rl.question("Ingrese la cantidad a retirar: ", (cantidad) => {
            cuenta.retirar(parseFloat(cantidad));
            cuenta.imprimirInfo();
            rl.close();
        });
    } else {
        console.log("Opción inválida.");
        rl.close();
    }
});
