// Sigue la demostración del profesor en la sesión de clase sobre los ejemplos básicos para 
// crear un servidor web que se ejecute sobre node, reciba peticiones de un cliente, y le responda.

// para iniciar el servidor en terminal: node scriptServer.js
// para cerrar el servidor en terminal: ctrl+c

// Este es un servidor Echo funcional simple.

const http = require('node:http');
http
  .createServer((request, response) => {
    request.on('error', err => {
      console.error(err);
      response.statusCode = 400;
      response.end();
    });
    response.on('error', err => {
      console.error(err);
    });
    if (request.method === 'POST' && request.url === '/echo') {
      request.pipe(response);
    } else {
      response.statusCode = 404;
      response.end();
    }
  })
  .listen(8080);

//   Instrucciones probar el server en Postman:
//   Abre Postman en tu dispositivo.
//   En la barra de direcciones, ingresa la URL de tu servidor. Si estás ejecutando el servidor en tu máquina local, será algo como http://localhost:8080.
//   Selecciona el método HTTP que deseas probar. En este caso, dado que el servidor espera una solicitud POST para la ruta /echo, selecciona POST del menú desplegable.
//   Haz clic en el área de Body debajo de la barra de direcciones para expandir las opciones del cuerpo de la solicitud.
//   Selecciona raw como tipo de cuerpo y luego elige Text en el menú desplegable al lado de raw.
//   Escribe el texto que deseas enviar en el cuerpo de la solicitud en el área de texto.
//   Haz clic en el botón "Send" (Enviar) para enviar la solicitud al servidor.
//   Deberías recibir una respuesta del servidor que contendrá el mismo texto que enviaste.