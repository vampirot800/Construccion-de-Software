// Una función que reciba un string y escriba el string en un archivo de texto. 
// Apóyate del módulo fs.

// Para correr en terminal: node script2node.js

"use strict";

const fs = require('fs');

function escribirEnArchivo(texto, nombreArchivo) {
    fs.writeFile(nombreArchivo, texto, (err) => {
        if (err) {
            console.error("Error al escribir en el archivo:", err);
            return;
        }
        console.log("Se ha escrito correctamente en el archivo" + nombreArchivo);
    });
}


const texto = "Hola mundo!";
const nombreArchivo = "archivo.txt";
escribirEnArchivo(texto, nombreArchivo);
