// Entrada: Usando un prompt se pide el resultado de la suma de 2 números generados de manera aleatoria. 
// Salida: La página debe indicar si el resultado fue correcto o incorrecto, y el tiempo que tardó el usuario en escribir la respuesta.

"use strict";

function randomNumber(max, min){
    return Math.floor(Math.random() * (max - min + 1)) + min
}
let startTimer = Date.now()

let num1 = randomNumber(1,100)
let num2 = randomNumber(1,100)

let userInput = prompt('Ingresa el resultado de la siguiente suma:'+ num1 + "+" + num2)

let endTimer = Date.now()

let answerTime = (endTimer - startTimer) / 1000

let answer = num1 + num2
    
if (userInput != null && userInput !== "" && !isNaN(userInput)) {
    if (parseInt(userInput) === answer) {
        alert("¡Respuesta correcta! \nEl tiempo de respuesta fue: "+ answerTime + " segundos.")
    } else {
        alert("Respuesta incorrecta. La suma es " + answer+"\nEl tiempo de respuesta fue: "+ answerTime + " segundos.")
    }
} else {
    alert("Debes ingresar un número válido.")

}
