// Crea una solución para un problema de tu elección (puede ser algo relacionado con tus intereses,
// alguna problemática que hayas identificado en algún ámbito, un problema de programación que 
// hayas resuelto en otro lenguaje, un problema de la ACM, entre otros). 
// El problema debe estar descrito en un documento HTML, y la solución implementada en JavaScript, 
// utilizando al menos la creación de un objeto, el objeto además de su constructor deben tener al menos 2 métodos.
//  Muestra los resultados en el documento HTML.

// Este programa simula una cuenta bancaria simple, haciendo uso de objetos, constructores y metodos
// La cuenta bancaria guarda los datos del usuario y el monto de dinero dentro. El usuario puede hacer uso
// de dos metodos, depositar, y retirar. Estos dos metodos actualizaran el monto total en la cuenta.

"use strict";

class CuentaBancaria {
    constructor(titular, RFC, saldo = 0) {
        this.titular = titular;
        this.RFC = RFC;
        this.saldo = saldo;
    }

    depositar(cantidad) {
    if (cantidad > 0) {
    this.saldo += cantidad;
    console.log("Se han depositado: $" +cantidad+ " pesos en la cuenta.");
    } else {
    console.log("La cantidad a depositar debe ser mayor que cero.");
    }
    }

    retirar(cantidad) {
    if (cantidad > 0 && cantidad <= this.saldo) {
    this.saldo -= cantidad;
    console.log("Se han retirado: $" +cantidad+ "pesos de la cuenta.");
    } else {
    console.log("No se puede retirar la cantidad especificada. Fondos insuficientes o cantidad inválida.");
    }
    }

    imprimirInfo() {
        alert("Información de la cuenta:\n" + "Titular: " + this.titular + "\nRFC: " + this.RFC + "\nSaldo actual: $" + this.saldo);
    }
}

let cuenta = new CuentaBancaria("Ramiro Flores Villarreal", "FOVR021020P94", 5000);
cuenta.imprimirInfo();

let opcion = prompt("¿Qué desea hacer? (depositar/retirar)");
if (opcion === "depositar") {
    let cantidad = parseFloat(prompt("Ingrese la cantidad a depositar:"));
    cuenta.depositar(cantidad);
} else if (opcion === "retirar") {
    let cantidad = parseFloat(prompt("Ingrese la cantidad a retirar:"));
    cuenta.retirar(cantidad);
} else {
    console.log("Opción inválida.");
}

cuenta.imprimirInfo();
