// Entrada: un número pedido con un prompt. 
// Salida: Una tabla con los números del 1 al número dado con sus cuadrados y cubos. Utiliza document.write para producir la salida

"use strict";

function Tabla(num){
    document.write("<h2>Tabla de Cuadrados y Cubos hasta " + num + "</h2>")
    document.write("<table border='1'>")
    document.write("<tr><th>Número</th><th>Cuadrado</th><th>Cubo</th></tr>")

    for(let i = 1; i <= num; i++){
        let cuadrado = i ** 2 
        let cubo = i ** 3
        document.write("<tr><td>" + i + "</td><td>" + cuadrado + "</td><td>" + cubo + "</td></tr>")
    }
    document.write("</table>")

}

let input = prompt('Ingresa un numero:')

let num = parseInt(input)

if(!isNaN(num) && num > 0){
    Tabla(num)  
} else if (input === null) {
    alert('Has cancelado el ingreso.');
} else{
    alert('Ingresa un numero valido')
}