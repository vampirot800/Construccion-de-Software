// Función: inverso. 
// Parámetros: Un número. 
// Regresa: El número con sus dígitos en orden inverso.

"use strict";

function inverso(num){
    let numString = num.toString();
    let caracteres = numString.split('');

    let caracteresInvertidos = caracteres.reverse();

    let numInvertido = parseInt(caracteresInvertidos.join(''));

    return numInvertido
}

let num = prompt('Ingresa un numero de 3 digitos: ')
if(num.length !== 3) {
    alert("El número ingresado no tiene 3 dígitos.");
} else {
    let result = inverso(num)
    alert   ("El numero invertido es: " + result)
}
