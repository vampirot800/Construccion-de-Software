// Función: contador. 
// Parámetros: Un arreglo de números. 
// Regresa: La cantidad de números negativos en el arreglo, la cantidad de 0's, y la cantidad de valores mayores a 0 en el arreglo.

"use strict";

function randomNumber(min, max){
    return Math.floor(Math.random() * (max - min + 1)) + min
}

function randomArray(cant, min, max){
    let array = [];
    for (let i = 0; i < cant; i++) {
        array.push(randomNumber(min, max));
    }
    return array;
}

function contador(arr){
    let negativos = 0;
    let ceros = 0;
    let mayoresCero = 0;

    for (let i = 0; i < arr.length; i++) {
        if (arr[i] < 0) {
            negativos++;
        } else if (arr[i] === 0) {
            ceros++;
        } else {
            mayoresCero++;
        }
    }

    return {
        negativos: negativos,
        ceros: ceros,
        mayoresCero: mayoresCero
    };

}
const cant = 10
let min = -1000
let max = 1000

let arr = randomArray(cant, min, max)
let conteo = contador(arr);
alert('Arreglo aleatorio:'+ arr +"\nCantidad de números negativos: " + conteo.negativos +"\nCantidad de ceros:"+ conteo.ceros +"\nCantidad de valores mayores a cero:" + conteo.mayoresCero)



